# 空预测格式演示

此包只用于理解模型包保存、SHA 声明和结果打包流程，不是训练模型。它不包含模型权重、真实标注或隐藏答案，对所有图像输出空实例，得分为 0。

环境：Python 3.10 或更高版本，仅使用标准库，不需要联网或安装额外依赖。

使用公开图像清单生成结果：

```bash
python infer.py images_test_b.json result.json
```

也支持题面规定的入口形式：

```bash
python inference.py --input_dir testB/images --output_path result.json
```

演示程序不需要权重；真实方案应自行实现权重加载、预处理、推理和后处理，并按题面提供完整模型包。不要用演示包的 SHA 声明自己的模型。
