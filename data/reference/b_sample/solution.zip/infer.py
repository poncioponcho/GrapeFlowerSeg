#!/usr/bin/env python3
"""Public, label-free empty-result demo. This is not a trained model."""

import argparse
import json
from pathlib import Path


def empty_result(names):
    if len(names) != 106 or len(set(names)) != 106:
        raise ValueError("请提供本次 B 榜全部 106 个不同图像文件名")
    return {"version": "1.0", "results": [
        {"image_id": name, "instances": []} for name in names
    ]}


def main():
    parser = argparse.ArgumentParser(description="无模型、无答案的空预测格式演示")
    parser.add_argument("image_metadata", help="公开 images_test_b.json")
    parser.add_argument("output", help="输出 result.json")
    args = parser.parse_args()
    metadata = json.loads(Path(args.image_metadata).read_text(encoding="utf-8"))
    result = empty_result([row["image_id"] for row in metadata])
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
