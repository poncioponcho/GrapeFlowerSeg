#!/usr/bin/env python3
"""Same empty demo using the statement's inference command-line interface."""

import argparse
import json
from pathlib import Path

from infer import empty_result


def main():
    parser = argparse.ArgumentParser(description="空预测演示：仅演示官方推理入口，不加载模型")
    parser.add_argument("--input_dir", required=True)
    parser.add_argument("--weights", default=None, help="演示不加载权重；真实模型必须实现")
    parser.add_argument("--output_path", required=True)
    args = parser.parse_args()
    names = sorted(path.name for path in Path(args.input_dir).glob("*.jpg") if path.is_file())
    result = empty_result(names)
    Path(args.output_path).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
