# solution.zip - 阳光玫瑰葡萄花穗完整性判断与分割

复现环境（题面规定）：Ubuntu 22.04 / Python 3.10 / PyTorch 2.2 / CUDA 12.1 /
单张 NVIDIA GPU / Batch Size = 1。

## 安装

```bash
pip install -r requirements.txt
```

## 推理

```bash
python inference.py \
  --input_dir test_images/ \
  --weights model/best.pt \
  --output_path reproduced_result.json
```

可选：`--manifest images_test_b.json` 提供逐图宽高；`--score_threshold` 控制输出阈值。

输出为 `result.json` 格式：`category_id` 0=完整花穗、1=不完整花穗；
`segmentation` 为 COCO compressed RLE。每张图恰好一条记录，无检测时
`"instances": []`。

## 当前状态

⚠️ 本包当前为**占位版本**：`model/` 内没有真实权重，`inference.py` 会为每张图
输出空的 `instances`，格式合法但官方得分为 0。

这是刻意设置的保底包：确保截止前一定存在一次**格式有效**的提交。训练完成后，
把真实权重放入 `model/`、补齐 `model/model.py`，重新推理并**重新打包**，
然后对新的 `solution.zip` 重新生成 `solution_commit.txt`（SHA 必须与本次
提交的结果一一对应）。

## 重要

- 赛后复核会断网运行本包，并比对复现结果与榜单成绩（Mask mAP 绝对差 ≤ 0.005）。
- 打包后**不要**重新压缩或修改 `solution.zip`：声明绑定的是原始字节的 SHA-256。
- 使用的预训练权重与开源模型必须在下表中列明名称、版本与下载地址。
- 禁止联网调用 API、禁止使用外部数据或测试集查表。

## 依赖与预训练权重

| 项目 | 名称 | 版本 | 来源 |
|---|---|---|---|
| 框架 | PyTorch | 2.2 | https://pytorch.org |
| 框架 | torchvision | 0.17 | https://pytorch.org |
| 预训练 | （训练完成后填写） | | |

## 目录结构

```text
solution.zip
├── model/            # 模型权重与网络定义
├── config/           # 推理配置
├── src/              # 推理源码
├── inference.py      # 统一推理入口
├── requirements.txt  # 依赖及版本
└── README.md         # 本文件
```
