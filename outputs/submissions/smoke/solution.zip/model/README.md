# model/

模型权重目录。

**当前为空** —— 这是占位版本，`inference.py` 在找不到权重时会为每张图输出空的
`instances`（格式合法，官方得分 0）。

训练完成后放入：

```text
model/
├── best.pt      # 权重
└── model.py     # 网络定义（PanicleSegmenter 类，含 .load() 与 .predict()）
```

`inference.py` 通过 `from model.model import PanicleSegmenter` 导入，
需要提供：

```python
class PanicleSegmenter:
    @classmethod
    def load(cls, weights_path, *, device="cuda") -> "PanicleSegmenter": ...

    def eval(self) -> None: ...

    def predict(self, image_path, width, height) -> list[dict]:
        """返回 [{"category_id": 0|1, "score": float,
                  "segmentation": {"size": [h, w], "counts": str}}, ...]"""
```

替换权重后必须**重新打包 `solution.zip` 并重新生成 `solution_commit.txt`**，
SHA 必须与本次提交的结果一一对应。
